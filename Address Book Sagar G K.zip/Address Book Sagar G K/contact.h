#ifndef CONTACT_H
#define CONTACT_H

typedef struct 
{
   char name[100];
   char number[11];
   char email[50];
   char address[100];
}contact;

void addcontact(contact contacts[],int*count);
void displaycontacts(contact contacts[],int count);
void searchcontact(contact contacts[],int count);
void editcontact(contact contacts[],int count);
void deletecontact(contact contacts[],int*count);
int validatemobile(char number[]);
int isNumberExists(contact contacts[],int count,char number[]);
int isNumberExistsExcept(contact contacts[],int count,char number[],int index);
int validatename(char name[]);
int validateemail(char email[]);
#endif
