
#include <stdio.h>
#include "contact.h"
#include "file.h"

/* Save contacts into binary file */
void savecontacts(contact contacts[], int count)
{
    FILE *fp;
    size_t saved;

    fp = fopen("contacts.dat", "wb");

    if (fp == NULL)
    {
        perror("Unable to save contacts.dat");
        return;
    }

    saved = fwrite(contacts, sizeof(contact), count, fp);

    if (saved != (size_t)count)
    {
        printf("Error while saving contacts.\n");
    }
    else
    {
        printf("%zu contacts saved successfully.\n", saved);
    }

    fclose(fp);
}

/* Load contacts from binary file */
void loadcontacts(contact contacts[], int *count)
{
    FILE *fp;
    size_t loaded;

    fp = fopen("contacts.dat", "rb");

    if (fp == NULL)
    {
        printf("Saved file not found. Using dummy contacts.\n");
        return;
    }

    loaded = fread(contacts, sizeof(contact), 100, fp);

    if (ferror(fp))
    {
        printf("Error while reading contacts.dat\n");
        fclose(fp);
        return;
    }

    *count = (int)loaded;

    fclose(fp);

    printf("%d contacts loaded successfully.\n", *count);
}

/* Export contacts into CSV file */
void exportcontacts(contact contacts[], int count)
{
    FILE *fp;
    int i;

    fp = fopen("contactslist.csv", "w");

    if (fp == NULL)
    {
        perror("Unable to create contactlist.csv");
        return;
    }

    /* First line: total number of contacts */
    fprintf(fp, "%d\n", count);

    /* Write contact details */
    for (i = 0; i < count; i++)
    {
        fprintf(fp, "%s,%s,%s\n",
                contacts[i].name,
                contacts[i].number,
                contacts[i].email);
    }

    fclose(fp);

    printf("Contacts exported to contactslist.csv successfully.\n");
}
