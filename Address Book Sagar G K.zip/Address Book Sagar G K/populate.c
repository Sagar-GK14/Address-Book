#include<string.h>
#include<ctype.h>
#include "populate.h"

void convertlower(char name[])
{
    int i;
    for(i=0;name[i]!='\0';i++)
    {
        name[i]=tolower(name[i]);
    }
}

void populatecontacts(contact contacts[],int*count)
{
    strcpy(contacts[0].name, "sagar");
    strcpy(contacts[0].number, "9036968531");
    strcpy(contacts[0].email, "sagar@gmail.com");
    strcpy(contacts[0].address, "bengaluru");

    strcpy(contacts[1].name, "akshay");
    strcpy(contacts[1].number, "9036456852");
    strcpy(contacts[1].email, "akshay@gmail.com");
    strcpy(contacts[1].address, "chickmagalur");

    strcpy(contacts[2].name, "arjun");
    strcpy(contacts[2].number, "9036968520");
    strcpy(contacts[2].email, "arjun@gmail.com");
    strcpy(contacts[2].address, "mysore");

    *count = 3;

}