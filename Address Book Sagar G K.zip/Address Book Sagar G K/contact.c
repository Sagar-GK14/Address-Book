#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include"contact.h"
#include"populate.h"
#include"file.h"

void addcontact(contact contacts[],int*count)
{

do
{
    printf("Enter name : ");
    scanf(" %[^\n]", contacts[*count].name);

    if(!validatename(contacts[*count].name))
    {
        printf("Invalid name! Enter letters only.\n");
    }

} while(!validatename(contacts[*count].name));

convertlower(contacts[*count].name);

do
{
    printf("Enter mobile number :");
    scanf("%10s",contacts[*count].number);

    if(!validatemobile(contacts[*count].number))
    {
        printf("Invalid mobile number ! Enter exactly 10 digits.\n");
    }
    else if(isNumberExists(contacts,*count,contacts[*count].number))
    {
        printf("Mobile number already exists! \n");
    }

    
} while (!validatemobile(contacts[*count].number) || isNumberExists(contacts,*count,contacts[*count].number));


do
{
    printf("Enter email : ");
    scanf("%49s", contacts[*count].email);

    if(!validateemail(contacts[*count].email))
    {
        printf("Invalid email! Enter email ending with @gmail.com.\n");
    }

} while(!validateemail(contacts[*count].email));

printf("Enter Address : ");
scanf(" %[^\n]",contacts[*count].address);
(*count)++;
printf("Contact added successfully\n");
}

void searchcontact(contact contacts[],int count)
{
    char name[100];
    char number[11];
    char email[50];

    int matches[100];
    int matchcount=0;
    int i;
    int choice;

    printf("\n1.Name :");
    printf("\n2.Mobile number :");
    printf("\n3.Emaid-ID :");
    
    printf("\nEnter the choice :");

    if(scanf("%d", &choice) != 1)
    {
    printf("Invalid input!\n");

    int ch;
    while((ch = getchar()) != '\n' && ch != EOF);

    return;
    }
    

    if(choice==1)
    {    
    printf("Enter name to search :");
    scanf(" %[^\n]",name);
    convertlower(name);
    for(i=0;i<count;i++)
    {
        if(strcmp(contacts[i].name,name)==0)
        {
            matches[matchcount]=i;
            matchcount++;
        }
    }
    }

    else if(choice==2)
    {
    printf("Enter mobile number to search :");
    scanf("%10s",number);
    for(i=0;i<count;i++)
    {
        if(strcmp(contacts[i].number,number)==0)
        {
            matches[matchcount]=i;
            matchcount++;
        }
    }
    }

    else if(choice==3)
    {
    printf("Enter E-mail to search :");
    scanf("%49s",email);
    for(i=0;i<count;i++)
    {
        if(strcmp(contacts[i].email,email)==0)
        {
            matches[matchcount]=i;
            matchcount++;
        }
    }
    }
    else
    {
        printf("Invalid choice!");
        return;
    }

    if(matchcount==0)
    {
        printf("contact not found.\n");
        return;
    }

    printf("\n Matching Contacts :\n");

    for(i=0;i<matchcount;i++)
    {
        printf("\n%d. %s - %s\n",i+1,contacts[matches[i]].name,contacts[matches[i]].number);
        printf(" Email    : %s\n",contacts[matches[i]].email);
        printf(" Address  : %s\n",contacts[matches[i]].address);
    }


    if(matchcount>1)
    {

    printf("\nEnter contact index to search : ");
    scanf("%d",&choice);
    if(choice < 1 || choice > matchcount)
    {
        printf("Invalid choice! \n");
        return;
    }
    i=matches[choice -1];
    }
    else
    {
        i=matches[0];
    }

    printf("\nName       :%s\n",contacts[i].name);
    printf("Number       :%s\n",contacts[i].number);
    printf("Email        :%s\n",contacts[i].email);
    printf("Address      :%s\n",contacts[i].address);
}

void editcontact(contact contacts[], int count)
{
    char name[100];
    char number[11];
    char email[50];

    int matches[100];
    int matchcount = 0;
    int i;
    int choice;
    int index;

    printf("\nEdit Contact By :\n");
    printf("1. Name\n");
    printf("2. Mobile Number\n");
    printf("3. Email ID\n");

    printf("Enter choice : ");
    scanf(" %d", &choice);

    if(choice == 1)
    {
        printf("Enter name to Edit : ");
        scanf(" %[^\n]", name);

        convertlower(name);

        for(i = 0; i < count; i++)
        {
            if(strcmp(contacts[i].name, name) == 0)
            {
                matches[matchcount] = i;
                matchcount++;
            }
        }
    }

    else if(choice == 2)
    {
        printf("Enter mobile number to edit : ");
        scanf("%10s", number);

        for(i = 0; i < count; i++)
        {
            if(strcmp(contacts[i].number, number) == 0)
            {
                matches[matchcount] = i;
                matchcount++;
            }
        }
    }

    else if(choice == 3)
    {
        printf("Enter Email ID to edit : ");
        scanf("%49s", email);

        for(i = 0; i < count; i++)
        {
            if(strcmp(contacts[i].email, email) == 0)
            {
                matches[matchcount] = i;
                matchcount++;
            }
        }
    }

    else
    {
        printf("Invalid choice!\n");
        return;
    }

    if(matchcount == 0)
    {
        printf("Contact not found.\n");
        return;
    }

    printf("\nMatching Contacts:\n");

    for(i = 0; i < matchcount; i++)
    {
        printf("\n%d. %s - %s\n",
               i + 1,
               contacts[matches[i]].name,
               contacts[matches[i]].number);

        printf("Email   : %s\n", contacts[matches[i]].email);
        printf("Address : %s\n", contacts[matches[i]].address);
    }

    if(matchcount > 1)
    {
        printf("\nEnter contact index to Edit : ");
        scanf("%d", &choice);

        if(choice < 1 || choice > matchcount)
        {
            printf("Invalid choice!\n");
            return;
        }

        index = matches[choice - 1];
    }
    else
    {
        index = matches[0];
    }

    printf("\nEnter new name : ");
    scanf(" %[^\n]", contacts[index].name);

    convertlower(contacts[index].name);

    do
    {
        printf("Enter new mobile number : ");
        scanf("%10s", contacts[index].number);

        if(!validatemobile(contacts[index].number))
        {
            printf("Invalid mobile number! Enter exactly 10 digits.\n");
        }
        else if(isNumberExistsExcept(contacts, count,
                                      contacts[index].number, index))
        {
            printf("Mobile number already exists.\n");
        }

    } while(!validatemobile(contacts[index].number) ||
            isNumberExistsExcept(contacts, count,
                                 contacts[index].number, index));

    do
    {
        printf("Enter new email : ");
        scanf("%49s", contacts[index].email);

        if(!validateemail(contacts[index].email))
        {
            printf("Invalid email! Enter email ending with @gmail.com.\n");
        }

    } while(!validateemail(contacts[index].email));

    printf("Enter new address : ");
    scanf(" %[^\n]", contacts[index].address);

    printf("Contact updated successfully!\n");
}
void deletecontact(contact contacts[], int *count)
{
    char name[100];
    char number[11];
    char email[50];

    int matches[100];
    int matchcount = 0;
    int choice;
    int i;
    int index;

    printf("\nDelete Contact By :\n");
    printf("1. Name\n");
    printf("2. Mobile Number\n");
    printf("3. Email ID\n");

    printf("Enter choice : ");
    scanf("%d", &choice);


    /* Search by name */

    if (choice == 1)
    {
        printf("Enter name to delete : ");
        scanf(" %[^\n]", name);

        convertlower(name);

        for (i = 0; i < *count; i++)
        {
            if (strcmp(contacts[i].name, name) == 0)
            {
                matches[matchcount] = i;
                matchcount++;
            }
        }
    }


    /* Search by mobile number */

    else if (choice == 2)
    {
        printf("Enter mobile number to delete : ");
        scanf("%10s", number);

        for (i = 0; i < *count; i++)
        {
            if (strcmp(contacts[i].number, number) == 0)
            {
                matches[matchcount] = i;
                matchcount++;
            }
        }
    }


    /* Search by email */

    else if (choice == 3)
    {
        printf("Enter email ID to delete : ");
        scanf("%49s", email);

        for (i = 0; i < *count; i++)
        {
            if (strcmp(contacts[i].email, email) == 0)
            {
                matches[matchcount] = i;
                matchcount++;
            }
        }
    }


    /* Invalid choice */

    else
    {
        printf("Invalid choice!\n");
        return;
    }


    /* No contact found */

    if (matchcount == 0)
    {
        printf("Contact not found.\n");
        return;
    }


    /* Display matching contacts */

    printf("\nMatching Contacts:\n");

    for (i = 0; i < matchcount; i++)
    {
        printf("\n%d. %s - %s\n",
               i + 1,
               contacts[matches[i]].name,
               contacts[matches[i]].number);

        printf("Email   : %s\n",
               contacts[matches[i]].email);

        printf("Address : %s\n",
               contacts[matches[i]].address);
    }


    /* Select contact if multiple matches */

    if (matchcount > 1)
    {
        printf("\nEnter contact number to delete : ");
        scanf("%d", &choice);

        if (choice < 1 || choice > matchcount)
        {
            printf("Invalid choice!\n");
            return;
        }

        index = matches[choice - 1];
    }
    else
    {
        index = matches[0];
    }


    /* Delete contact by shifting */

    for (i = index; i < *count - 1; i++)
    {
        contacts[i] = contacts[i + 1];
    }


    /* Decrease total number of contacts */

    (*count)--;

    printf("\nContact deleted successfully!\n");
}
void displaycontacts(contact contacts[], int count)
{
    int i;

    if(count == 0)
    {
        printf("No contacts available.\n");
        return;
    }

    printf("\n================================================================================\n");

    printf("%-8s %-15s %-15s %-25s %-15s\n",
           "Sl.No", "Name", "Mobile No", "Email", "Address");

    printf("================================================================================\n");

    for(i = 0; i < count; i++)
    {
        printf("%-8d %-15s %-15s %-25s %-15s\n",
               i + 1,
               contacts[i].name,
               contacts[i].number,
               contacts[i].email,
               contacts[i].address);
    }

    printf("================================================================================\n");
}

int validatemobile(char number[])
{
    int i;
    if(strlen(number)!=10)
    {
        return 0;
    }
    for(i=0;number[i]!='\0';i++)
    {
        if(!isdigit(number[i]))
        {
            return 0;
        }
    }
    return 1;
}

int isNumberExistsExcept(contact contacts[],int count,char number[],int index)
{
    int i;
    for(i=0;i<count;i++)
    {
        if(i !=index && strcmp(contacts[i].number,number)==0)
        {
            return 1;
        }
    }
    return 0;
}

int isNumberExists(contact contacts[], int count, char number[])
{
    int i;

    for(i = 0; i < count; i++)
    {
        if(strcmp(contacts[i].number, number) == 0)
        {
            return 1;
        }
    }

    return 0;
}


int validatename(char name[])
{
    int i;

    for(i = 0; name[i] != '\0'; i++)
    {
        if(!isalpha(name[i]) && name[i] != ' ')
        {
            return 0;
        }
    }

    return 1;
}

int validateemail(char email[])
{
    int len;

    len = strlen(email);

    if(len <= 10)
    {
        return 0;
    }

    if(strcmp(email + len - 10, "@gmail.com") != 0)
    {
        return 0;
    }

    return 1;
}