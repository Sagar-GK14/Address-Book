#ifndef FILE_H
#define FILE_H

#include "contact.h"

void savecontacts(contact contacts[], int count);
void loadcontacts(contact contacts[], int *count);
void exportcontacts(contact contacts[], int count);

#endif