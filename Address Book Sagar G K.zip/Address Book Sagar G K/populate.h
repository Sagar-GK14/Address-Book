#ifndef POPULATE_H
#define POPULATE_H

#include "contact.h"

void populatecontacts(contact contacts[], int *count);
void convertlower(char name[]);

#endif