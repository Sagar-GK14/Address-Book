#include <stdio.h>
#include "contact.h"
#include "populate.h"
#include"file.h"

int main()
{
    contact contacts[100];
    int count = 0;
    int choice;

    populatecontacts(contacts, &count);
    loadcontacts(contacts ,&count);
    exportcontacts(contacts, count);


    do
    {
        printf("\n==========ADDRESS BOOK ===========");
        printf("\n");
        printf("1. Add Contacts\n"); 
        printf("2. Display Contacts\n");
        printf("3. Search Contacts\n");
        printf("4. Edit Contacts\n");
        printf("5. Delete Contacts\n");
        printf("6. Exit\n");
        printf("\n");

        printf("Enter the choice: ");
        
       if(scanf("%d", &choice) != 1)
       {
       printf("Invalid input! Enter a number.\n");

       int ch;
       while((ch = getchar()) != '\n' && ch != EOF);

       continue;
       }

        printf("\n");
         
        switch(choice)
        {
            case 1:
                   addcontact(contacts,&count);
                   savecontacts(contacts, count);
                   exportcontacts(contacts, count);
                   break;

            case 2:
                   printf("Display Contact selected :\n");
                   displaycontacts(contacts,count);
                   break;
            case 3:
                   printf("Search Contact selected :\n");
                   searchcontact(contacts,count);
                   break;
            case 4:
                   printf("Edit Contact selected :\n");
                   editcontact(contacts,count);
                   savecontacts(contacts, count);
                   exportcontacts(contacts, count);
                   break;
            case 5:
                   printf("Delete Contact selected :\n ");
                   deletecontact(contacts,&count);
                   savecontacts(contacts, count);
                   exportcontacts(contacts, count);
                   break;
            case 6:
                   savecontacts(contacts, count);
                   printf("Contacts saved successfully!\n");
                   printf("Exiting Address Book. \n");
                   exportcontacts(contacts, count);
                   break;
            default:
                   printf("Invalid choice! \n");
        }
    }while(choice!=6);

    return 0;
}
   