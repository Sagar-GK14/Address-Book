# Address Book Management System in C

## 1. Introduction

The Address Book Management System is a menu-driven C programming project developed to store and manage contact information efficiently.

The application allows users to add, display, search, edit and delete contact details. Each contact contains a name, mobile number, email address and address.

The project uses structures, arrays, functions, pointers, string handling and file handling concepts in C.

It also provides permanent data storage using binary file handling and exports contact information into a CSV file for easy access.

## 2. Objectives

The main objectives of this project are:

- To understand and implement structures in C.
- To gain practical knowledge of functions, arrays and pointers.
- To perform contact management operations.
- To implement input validation for names, mobile numbers and email addresses.
- To prevent duplicate mobile numbers.
- To handle multiple contacts with the same name.
- To understand binary file operations using `fread()` and `fwrite()`.
- To maintain contact information between program executions.
- To export contact information into a CSV file using `fprintf()`.

## 3. Features

The Address Book Management System provides the following features:

1. **Add Contact:** Allows users to add new contacts with name, mobile number, email address and residential address.
2. **Display Contacts:** Displays all available contacts in a tabular format.
3. **Search Contact:** Allows users to search contacts using name, mobile number or email address.
4. **Edit Contact:** Allows users to modify the details of an existing contact.
5. **Delete Contact:** Allows users to remove an existing contact.
6. **Name Validation:** Accepts only alphabets and spaces and converts names into lowercase.
7. **Mobile Number Validation:** Accepts exactly 10 digits and prevents duplicate mobile numbers.
8. **Email Validation:** Checks whether the email address ends with `@gmail.com`.
9. **Duplicate Name Handling:** Displays all matching contacts and allows the user to select the required contact.
10. **Binary File Storage:** Saves and loads contact records using a binary file.
11. **CSV Export:** Exports contact information into `contactslist.csv`.
12. **Dummy Contacts:** Initially populates three sample contacts when no previously saved contact file is available.

## 4. Technologies Used

- **Programming Language:** C
- **Compiler:** GCC
- **Header Files:** `stdio.h`, `string.h`, `ctype.h`
- **Data Structures:** Structures and arrays
- **Pointers:** Used for passing and modifying contact counts.
- **String Handling:** `strcpy()`, `strcmp()`, `strlen()` and other string operations.
- **Character Handling:** `isalpha()`, `isdigit()` and `tolower()`.
- **File Handling:** `fopen()`, `fclose()`, `fread()`, `fwrite()` and `fprintf()`.
- **Storage Formats:** Binary file and CSV file.

## 5. Project Files

The project is divided into multiple source files and header files to maintain modularity and make the program easier to understand and maintain.

### 1. main.c
- Contains the main function.
- Displays the menu-driven interface.
- Accepts the user's choice.
- Uses a switch statement to call the appropriate functions.
- Calls file handling functions to save and export updated contact information.

### 2. contact.h
- Contains the contact structure definition.
- Declares functions related to adding, displaying, searching, editing and deleting contacts.
- Declares validation and duplicate-checking functions.

### 3. contact.c
- Implements contact management operations.
- Contains functions for adding, displaying, searching, editing and deleting contacts.
- Implements name, mobile number and email validation.
- Handles duplicate mobile numbers.
- Displays matching contacts when duplicate names are found.

### 4. populate.h
- Contains function declarations related to populating sample contacts and converting names into lowercase.

### 5. populate.c
- Initializes three dummy contacts.
- Sets the initial contact count.
- Implements the function to convert names into lowercase.

### 6. file.h
- Contains declarations of file handling functions.
- Declares functions for saving, loading and exporting contacts.

### 7. file.c
- Implements binary file operations.
- Uses `fwrite()` to save contact records into `contacts.dat`.
- Uses `fread()` to load previously saved contact records.
- Uses `fprintf()` to export contact details into `contactslist.csv`.

### 8. contacts.dat
- Stores contact records in binary format.
- Helps preserve contact information between program executions.

### 9. contactslist.csv
- Stores exported contact information in CSV format.
- Contains contact names, mobile numbers and email addresses.
- Can be opened using spreadsheet applications.

## 6. Program Execution

When the program starts, the following operations take place:

1. Memory is allocated for storing contact records.
2. Three dummy contacts are initialized.
3. The program checks for the existence of `contacts.dat`.
4. If the binary file exists, previously saved contacts are loaded into the contact array.
5. The contact information is exported into `contactslist.csv`.
6. A menu is displayed to the user.
7. The user selects an operation.
8. The selected function performs the required operation.
9. After adding, editing or deleting contacts, the updated information is saved into the binary file and exported into the CSV file.
10. When the user selects Exit, the latest contact information is saved before terminating the application.

## 7. Data Storage and File Handling

The project uses two different file formats to store contact information.

### A. Binary File Handling

The binary file `contacts.dat` is used for permanent storage of contact records.

**Saving Contacts:**

The `savecontacts()` function uses:

- `fopen()` with `"wb"` mode to open the binary file.
- `fwrite()` to write contact structures into the file.
- `fclose()` to close the file.

**Loading Contacts:**

The `loadcontacts()` function uses:

- `fopen()` with `"rb"` mode to open the binary file.
- `fread()` to read contact records.
- Updates the contact count with the number of records loaded.
- `fclose()` to close the file.

### B. CSV File Export

The project also exports contact information into `contactslist.csv`.

The `exportcontacts()` function uses:

- `fopen()` with `"w"` mode to create or overwrite the CSV file.
- `fprintf()` to write the total number of contacts and contact details.
- `fclose()` to close the file.

The exported contact details follow this format:

```text
7
sagar,9036968531,sagar@gmail.com
akshay,9036456852,akshay@gmail.com
arjun,9036968520,arjun@gmail.com
praju,8585902354,praju@gmail.com
prakash,7410852963,prakash@gmail.com
sdfghj,8520741963,sdfgh@gmail.com
sagar,9036968562,sagar@gmail.com
```

The first line represents the total number of contacts. Each subsequent line contains the name, mobile number and email address separated by commas.

## 8. Sample Menu

The application displays the following menu:

```text
========== ADDRESS BOOK ==========

1. Add Contacts
2. Display Contacts
3. Search Contacts
4. Edit Contacts
5. Delete Contacts
6. Exit

Enter the choice:
```

The user can select an operation by entering the corresponding number.

## 9. Advantages

- Makes contact management easier and more organized.
- Demonstrates modular programming using multiple C files.
- Provides input validation for contact information.
- Prevents duplicate mobile numbers.
- Supports handling of contacts with duplicate names.
- Maintains contact records using binary file handling.
- Provides CSV export for accessing contact information through spreadsheet applications.
- Improves understanding of structures, arrays, pointers, functions and file handling.

## 10. Conclusion

The Address Book Management System demonstrates the practical implementation of important C programming concepts, including structures, arrays, functions, pointers, string handling, input validation and file handling.

The project provides essential contact management operations such as adding, displaying, searching, editing and deleting contacts.

By implementing binary file storage and CSV export, the application provides both persistent data storage and an accessible format for viewing contact information.

This project helped develop practical programming skills, problem-solving abilities and an understanding of modular programming in C.